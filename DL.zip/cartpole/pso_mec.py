import numpy as np
import pymysql
import matplotlib.pyplot as plt
import final_mec_env

env = final_mec_env.ENV
np.random.seed(1)
num_device = 50
s_dim = num_device * 4
a_dim = num_device * 4
num_mec = 4
mec_max_cpu = 12
mec_q_acc = 12
t_threshold = 100
# offload_x = np.random.uniform(0, 1, num_device)
# local_f = np.random.uniform(0, 1, num_device)  # cpu归一化处理 [0,1] ->[2 * 10^9 , 4 * 10^9]
# local_f = np.ceil(local_f * (10 ** 9))
# send_p = np.random.uniform(0, 1, num_device)  # 归一化
mec_f = np.array([10 ** 10, 10 ** 10, 10 ** 10, 10 ** 10])
channel_c = np.random.randint(0, 13, num_device)
d = np.random.randint(0., 500., (num_device, num_mec))
b = np.random.uniform(100, 1000, num_device)
b = np.ceil(b * 1000 * 1024)
# mec_c = np.random.uniform(0, 1, num_device)  # 归一化
task_priority = np.random.uniform(0, 1, num_device)
task_quality = np.random.uniform(0, 1, num_device)


class PSO(object):
    def __init__(self, population_size, max_steps):
        self.w = 0.4  # 惯性权重
        self.c1 = self.c2 = 2
        self.population_size = population_size  # 粒子群数量
        self.dim = 200  # 搜索空间的维度
        self.max_steps = max_steps  # 迭代次数
        self.x_bound = [0, 1]  # 解空间范围
        self.x = np.random.uniform(self.x_bound[0], self.x_bound[1],
                                   (self.population_size, self.dim))  # 初始化粒子群位置
        self.v = np.random.rand(self.population_size, self.dim)  # 初始化粒子群速度
        offload_x = self.x[0: 50]  # 卸载率
        local_f = self.x[50: 100]  # 本地cpu频率
        send_p = self.x[100: 150]  # 发送功率
        mec_c = self.x[150: 200]  # 发送至服务器n
        self.env = env(num_device, offload_x, local_f, mec_f, send_p, channel_c, d, b, num_mec,
                  task_quality, mec_c, t_threshold, mec_max_cpu, mec_q_acc, task_priority)
        fitness = self.calculate_fitness(self.x)
        self.p = self.x  # 个体的最佳位置
        self.pg = self.x[np.argmax(fitness)]  # 全局最佳位置
        self.individual_best_fitness = fitness  # 个体的最优适应度
        self.global_best_fitness = np.max(fitness)  # 全局最佳适应度
        self.u_all = []

    def calculate_fitness(self, x):
        fitness = []
        for i in range(x.shape[0]):
            # pubish = 0
            # for j in x[i]:
            #     if j < 0:
            #         pubish += (0 - j) * 1000
            #     if j > 1:
            #         pubish += (j - 1) * 1000
            # x[i] = np.clip(x[i], 0, 1)
            e, t, u = self.env.calculate_cost_by_state(x[i])
            fitness.append(u)
        return fitness

    def evolve(self):
        conn = pymysql.connect(
            host='localhost',
            user='root',
            password='654321',
            db='p3o',
            charset='utf8',
            # autocommit=True,    # 如果插入数据，， 是否自动提交? 和conn.commit()功能一致。
        )
        cur = conn.cursor()
        for step in range(self.max_steps):
            r1 = np.random.rand(self.population_size, self.dim)
            r2 = np.random.rand(self.population_size, self.dim)
            # 更新速度和权重
            self.v = self.w * self.v + self.c1 * r1 * (self.p - self.x) + self.c2 * r2 * (self.pg - self.x)
            self.x = self.v + self.x
            self.x = np.clip(self.x, 0, 1)
            fitness = self.calculate_fitness(self.x)
            # 需要更新的个体
            update_id = np.greater(self.individual_best_fitness, fitness)
            fitness = np.array(fitness)
            self.individual_best_fitness = np.array(self.individual_best_fitness)
            self.p[update_id] = self.x[update_id]
            self.individual_best_fitness[update_id] = fitness[update_id]
            # 新一代出现了更小的fitness，所以更新全局最优fitness和位置
            if np.max(fitness) > self.global_best_fitness:
                self.pg = self.x[np.argmax(fitness)]
                self.global_best_fitness = np.max(fitness)
            print('best fitness: %.5f,  fitness: %.5f' % (self.global_best_fitness,
                                                          np.sum(fitness)))
            if step % 10 == 0:
                try:
                    insert_sqli = "insert into pso_u (pso_u.u) values(%s)"
                    cur.execute(insert_sqli, self.global_best_fitness)

                except Exception as e:
                    print("插入数据失败:", e)
                else:
                    conn.commit()
            self.u_all.append(self.global_best_fitness)
            if step == self.max_steps - 1:
                print(self.pg[0: 50])
                print(self.pg[50: 100])
                print(self.pg[100: 150])
                print(self.pg[150: 200])
        plt.plot(np.arange(len(self.u_all)), self.u_all)
        plt.show()


pso = PSO(100, 2500)
pso.evolve()