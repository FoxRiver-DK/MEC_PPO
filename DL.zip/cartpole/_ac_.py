import numpy as np
import tensorflow as tf
import gym
import math

np.random.seed(2)
tf.set_random_seed(2)

# 在200分前不显示图像
DISPLAY_REWARD_THRESHOLD = 200
RENDER = False

# 是否输出图像
OUTPUT_GRAPH = False

# 最大世代
MAX_EPISODE = 3000
MAX_EP_STEPS = 1000  # maximum time step in one episode

# 衰减率
GAMMA = 0.9

# 两个神经网络的学习率
LR_A = 0.001  # actor学习率
LR_C = 0.01  # critic学习率

env = gym.make('CartPole-v0')
env.seed(1)
env = env.unwrapped

# 环境的维度
N_F = env.observation_space.shape[0]
# 动作的数量
N_A = env.action_space.n


class Actor(object):
    def __init__(self, sess, n_features, n_actions, lr=0.001):
        self.sess = sess
        # 状态
        self.s = tf.placeholder(tf.float32, [1, n_features], "state")
        # 动作
        self.a = tf.placeholder(tf.int32, None, "act")
        # TD_error
        self.td_error = tf.placeholder(tf.float32, None, "td_error")

        with tf.variable_scope('Actor'):
            l1 = tf.layers.dense(
                inputs=self.s,
                units=20,  # 二十个神经元
                activation=tf.nn.relu,
                kernel_initializer=tf.random_normal_initializer(0., .1),
                bias_initializer=tf.constant_initializer(0.1),
                name='l1'
            )

            l2 = tf.layers.dense(
                inputs=l1,
                units=n_actions,  # 状态的维度
                activation=None,  # 获得执行每个动作的可能性
                kernel_initializer=tf.random_normal_initializer(0., .1),
                bias_initializer=tf.constant_initializer(0.1),
                name='acts_prob'
            )
            self.acts_prob = tf.nn.softmax(l2)
        label = [self.a]
        with tf.variable_scope('exp_v'):
            # 可以通过最小化-(log_p * R)的方式实现最大化(log_p * R)
            neg_log_prob = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=l2, labels=label)
            self.exp_v = tf.reduce_mean(neg_log_prob * self.td_error)

        with tf.variable_scope('train'):
            self.train_op = tf.train.AdamOptimizer(lr).minimize(self.exp_v)  # minimize(-exp_v) = maximize(exp_v)

    def learn(self, s, a, td):
        s = s[np.newaxis, :]
        feed_dict = {self.s: s, self.a: a, self.td_error: td}
        _, exp_v = self.sess.run([self.train_op, self.exp_v], feed_dict)
        return exp_v

    def choose_action(self, s):
        s = s[np.newaxis, :]
        # 获得所有动作的概率
        probs = self.sess.run(self.acts_prob, {self.s: s})

        # 返回按照一定概率选择的动作
        return np.random.choice(np.arange(probs.shape[1]), p=probs.ravel())


class Critic(object):
    def __init__(self, sess, n_features, lr=0.01):
        self.sess = sess
        # s是状态
        self.s = tf.placeholder(tf.float32, [1, n_features], "state")
        # 下一个状态的预计value
        self.v_ = tf.placeholder(tf.float32, [1, 1], "v_next")
        # r是得分
        self.r = tf.placeholder(tf.float32, None, 'r')

        with tf.variable_scope('Critic'):
            l1 = tf.layers.dense(
                inputs=self.s,
                units=20,
                activation=tf.nn.relu,
                kernel_initializer=tf.random_normal_initializer(0., .1),
                bias_initializer=tf.constant_initializer(0.1),
                name='l1'
            )

            self.v = tf.layers.dense(
                inputs=l1,
                units=1,  # output units
                activation=None,
                kernel_initializer=tf.random_normal_initializer(0., .1),
                bias_initializer=tf.constant_initializer(0.1),
                name='V'
            )

        with tf.variable_scope('squared_TD_error'):
            # 获取下一个环境得分与该环境的差
            # self.r + GAMMA * self.v_为现实的价值，V_eval为预计的价值
            self.td_error = self.r + GAMMA * self.v_ - self.v
            self.loss = tf.square(self.td_error)  # TD_error = (r+gamma*V_next) - V_eval
        with tf.variable_scope('train'):
            self.train_op = tf.train.AdamOptimizer(lr).minimize(self.loss)

    def learn(self, s, r, s_):
        s, s_ = s[np.newaxis, :], s_[np.newaxis, :]

        # 获得下一个环境的预测得分
        v_ = self.sess.run(self.v, {self.s: s_})

        td_error, _ = self.sess.run([self.td_error, self.train_op],
                                    {self.s: s, self.v_: v_, self.r: r})
        return td_error


sess = tf.Session()

# critic输出的数据会为actor进行指导，所以critic需要训练的更快一些
actor = Actor(sess, n_features=N_F, n_actions=N_A, lr=LR_A)
critic = Critic(sess, n_features=N_F, lr=LR_C)

sess.run(tf.global_variables_initializer())

if OUTPUT_GRAPH:
    tf.summary.FileWriter("logs/", sess.graph)

for i_episode in range(MAX_EPISODE):
    s = env.reset()
    t = 0
    # 用于记录每一轮的得分
    track_r = []
    while True:
        if RENDER:
            env.render()

        a = actor.choose_action(s)

        s_, r, done, info = env.step(a)

        x, x_dot, theta, theta_dot = s_

        # r1代表车的 x水平位移 与 x最大边距 的距离差的得分
        r1 = math.exp((env.x_threshold - abs(x)) / env.x_threshold) - math.exp(1) / 2
        # r1代表棒子的 theta离垂直的角度 与 theta最大角度 的差的得分
        r2 = math.exp((env.theta_threshold_radians - abs(theta)) / env.theta_threshold_radians) - math.exp(1) / 2
        # 总 reward 是 r1 和 r2 的结合, 既考虑位置, 也考虑角度。
        r = r1 + r2

        # 如果没有撑过1000回合，则得分为-20一次,失败前的那个动作是肯定是错误的，所以给了负回报
        if done:
            r = -20

        track_r.append(r)

        td_error = critic.learn(s, r, s_)  # gradient = grad[r + gamma * V(s_) - V(s)]

        actor.learn(s, a, td_error)  # true_gradient = grad[logPi(s,a) * td_error]

        # 状态更新
        s = s_

        # t++
        t += 1

        if done or t >= MAX_EP_STEPS:
            ep_rs_sum = sum(track_r)

            if 'running_reward' not in globals():
                running_reward = ep_rs_sum
            else:
                # 保留95%过去的得分，并加上5%现在的得分
                running_reward = running_reward * 0.95 + ep_rs_sum * 0.05
            if running_reward > DISPLAY_REWARD_THRESHOLD:
                RENDER = True
            print("episode:", i_episode, "  reward:", int(running_reward))
            break

