#  mec环境简单版
#  K个物联网设备和一个MEC服务器，
#  状态state 每个任务的卸载率X = {x1,x2,...xK}
#  动作action，因为要是连续用作用ddqn解决，所以卸载率为部分卸载，假设action范围为[0,1]
import math

import numpy as np

num_d = 50
h = 0.98
v = 4.
N = 10 ** -11
alpha_k = np.random.uniform(10, 20, num_d)
w = 10 ** 8
yita = 1.2
lamb = 10 ** (-26)
t_threshold = 1000
k_t = 0.7
k_e = 0.3
a_bound = 1
a_low_bound = 0
f_bound = 6  # 本地cpu频率的边界，别忘了乘10^9
f_low_bound = 2
f_index = 10 ** 9


class env(object):
    def __init__(self, num_device, offload_x, local_f, mec_f, send_p, channel_c, d, i):
        self.num_device = num_device  # k
        self.offload_x = offload_x  # 1 * k
        self.local_f = local_f  # 1 * k
        self.mec_f = mec_f  # 1 * 1
        self.send_p = send_p  # 1 * k
        self.channel_c = channel_c  # 1 * k
        self.d = d  # 1 * k 到mec的距离
        self.i = i  # 1 * k 任务量
        self.t_threshold = 400

    def calculate_co_channel_interference(self):
        np.array(self.offload_x)
        nkc = np.zeros(self.num_device)
        for i in range(self.num_device):
            for c in range(self.num_device):
                if self.channel_c[i] == self.channel_c[c]:
                    nkc[i] += (self.d[c] ** (-v)) * (h ** 2)
        co_channel_interference = np.divide(self.send_p * (self.d ** (-v)) * (h ** 2), N)
        return co_channel_interference

    def calculate_all_delay(self):
        f = self.calculate_cpu_f()
        t_local = np.divide(alpha_k * (1 - self.offload_x) * self.i, f)
        sinr = self.calculate_co_channel_interference()
        r = w * np.log2(1 + sinr)
        t_communication = np.divide(yita * self.offload_x * self.i, r)
        t_mec = np.divide(alpha_k * self.offload_x * self.i, self.mec_f)
        t_all = np.zeros(num_d)
        for i in range(num_d):
            t_all[i] = max(t_local[i], t_communication[i] + t_mec[i])
        # print(t_all[0])
        return t_all, t_communication

    def calculate_all_energy(self, t_communication):
        f = self.calculate_cpu_f()
        # 先计算总时延，里面有个信道传输时间需要用到
        e_local = lamb * (f ** 2) * alpha_k * (1 - self.offload_x) * self.i
        e_send = self.send_p * 18 * t_communication
        e_all = e_send + e_local
        return e_all

    def calculate_comprehensive_cost(self):
        t_all, t_communication = self.calculate_all_delay()
        e_all = self.calculate_all_energy(t_communication)
        cost_all = k_t * t_all + k_e * e_all
        return t_all, e_all, cost_all

    def calculate_cpu_f(self):  # mec中的f在（0，1）之间，归一化处理
        f = self.local_f
        f = f * (f_bound - f_low_bound) + f_low_bound
        f = np.ceil(f * (10 ** 9))
        return f

    def step(self, action):  # action [-1,1] && a + s [0,1]
        action = np.array(action)
        offload_x_d = action[0: num_d]  # 卸载率
        local_f_d = action[-num_d:]  # 本地cpu频率 [-1,1]

        t_all, e_all, cost_all = self.calculate_comprehensive_cost()
        offload_x = self.offload_x
        local_f = self.local_f

        s = np.append(offload_x, local_f)   # [0,1]
        offload_x_ = offload_x + offload_x_d
        local_f_ = local_f + local_f_d  # [0,1]

        self.offload_x = offload_x_
        self.local_f = local_f_  # [0,1]

        s_ = np.append(offload_x_, local_f_)

        for i in s_:
            if i < 0:
                print("error_0")
            if i > 1:
                print("error_1")

        t_all_, e_all_, cost_all_ = self.calculate_comprehensive_cost()
        # r = np.zeros(num_d)
        r = 0
        e_all = np.sum(e_all)
        t_all = np.sum(t_all)
        cost_all = np.sum(cost_all)

        e_all_ = np.sum(e_all_)
        t_all_ = np.sum(t_all_)
        cost_all_ = np.sum(cost_all_)
        if t_all <= t_all_:
            r += -10
        if t_all > t_all_:
            r += 10
        if e_all <= e_all_:
            r += -10
        if e_all > e_all_:
            r += 10
        if cost_all <= cost_all_:
            r += -15
        if cost_all > cost_all_:
            r += 15
        # r += np.sum(cost_all - cost_all_)
        # r += np.divide(np.sum(cost_all), np.sum(cost_all_ + cost_all))

        # return s, action, r, s_, np.sum(e_all_, axis=0), np.sum(t_all_, axis=0), \
        #        np.sum(cost_all_, axis=0)
        return s, action, r, s_, e_all_, t_all_, cost_all_

# np.random.seed(1)
# num_device = num_d
# offload_x = np.random.uniform(0, 1, num_device)
# local_f = np.random.uniform(0, 1, num_device)
# mec_f = 10 ** 10
# send_p = 0.4
# channel_c = np.random.randint(0, 13, num_device)
# d = np.random.randint(0., 500., num_device)
# i = np.random.uniform(100, 3000, num_device)
# i = np.ceil(i * 1000 * 1024)
# mec = env(num_device, offload_x, local_f, mec_f, send_p, channel_c, d, i)
# t_all, t_consumption = mec.calculate_all_delay()
# print(mec.calculate_all_energy(t_consumption))
