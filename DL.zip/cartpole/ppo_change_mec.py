import gym
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
from torch.autograd import Variable

import ppo_change_mec_enc

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
DISCRETE_MEMORY_CAPACITY = 5000
TARGET_REPLACE_ITER = 100



class ActorNet(nn.Module):
    def __init__(self, n_states, n_actions_discrete, n_actions_continuous, bound):
        super(ActorNet, self).__init__()
        self.n_states = n_states
        self.bound = bound

        self.layer = nn.Sequential(
            nn.Linear(self.n_states, 128),
            nn.ReLU()
        )

        self.mu_out = nn.Linear(128, n_actions_continuous)
        self.sigma_out = nn.Linear(128, n_actions_continuous)

        self.discrete_out = nn.Linear(128, n_actions_discrete)                                  # 设置第二个全连接层(隐藏层到输出层): 50个神经元到动作数个神经元
        self.discrete_out.weight.data.normal_(0, 0.1)

    def forward(self, x):
        x = F.relu(self.layer(x))
        mu = self.bound * torch.tanh(self.mu_out(x))
        sigma = F.softplus(self.sigma_out(x))
        discrete_out = torch.sigmoid(self.discrete_out(x))
        return mu, sigma, discrete_out


class CriticNet(nn.Module):
    def __init__(self, n_states, n_actions):
        super(CriticNet, self).__init__()
        self.n_states = n_states

        self.layer = nn.Sequential(
            nn.Linear(self.n_states, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )

    def forward(self, x):
        v = self.layer(x)
        return v


class PPO(nn.Module):
    def __init__(self, n_states, n_actions_discrete, n_actions_continuous, bound, args):
        super().__init__()
        self.n_states = n_states
        self.n_actions_discrete = n_actions_discrete
        self.n_actions_continuous = n_actions_continuous
        self.bound = bound
        self.lr = args.lr
        self.epsilon = args.epsilon
        self.a_update_steps = args.a_update_steps
        self.c_update_steps = args.c_update_steps
        self.continuous_actor_loss = []
        self.discrete_actor_loss = []
        self.critic_loss = []

        self.memory = np.zeros((DISCRETE_MEMORY_CAPACITY, n_states * 2 + n_actions + 4))  # 初始化记忆库，一行代表一个transition
        self.memory_counter = 0
        self.learn_step_counter = 0

        # pso参数
        self.actor_lr = 0.00004
        self.critic_lr = 0.00004
        self.actor_target_lr = 0.00004
        self.gamma = 0.88
        self.global_best = np.append(self.actor_lr, self.critic_lr)
        self.global_best = np.append(self.global_best, self.gamma)
        self.global_reward = 0
        self.x_pso = self.global_best
        self.v_pso = np.array([0.00005, 0.00005, 0.05])

        self._build()

    def _build(self):
        self.actor_model = ActorNet(n_states, n_actions_discrete, n_actions_continuous, bound)
        self.actor_old_model = ActorNet(n_states, n_actions_discrete, n_actions_continuous, bound)
        self.actor_target_model = ActorNet(n_states, n_actions_discrete, n_actions_continuous, bound)
        self.actor_optim = torch.optim.Adam(self.actor_model.parameters(), lr=self.actor_lr)
        self.actor_target_optim = torch.optim.Adam(self.actor_model.parameters(), lr=self.actor_target_lr)

        self.critic_model = CriticNet(n_states, n_actions)
        self.critic_optim = torch.optim.Adam(self.critic_model.parameters(), lr=self.critic_lr)

    def choose_discrete_action(self, discrete_out):
        # if len(self.discrete_actor_loss) > 0:
        #     discrete_actor_loss_ = self.discrete_actor_loss[-1]
        #
        #     discrete_actor_loss_.requires_grad_(True)
        #     self.actor_optim.zero_grad()
        #     discrete_actor_loss_.backward()
        #     self.actor_optim.step()

        discrete_out = np.array(discrete_out.detach())
        discrete_out = discrete_out.reshape(num_device, 8)
        discrete_out = torch.tensor(discrete_out)
        out = torch.max(discrete_out, 1)[1].data.numpy()
        return out

    def choose_discrete_action_DQN(self, discrete_out):
        discrete_out = np.array(discrete_out.detach())
        discrete_out = discrete_out.reshape(num_device, 8)
        discrete_out = torch.tensor(discrete_out)
        return discrete_out

    def choose_action(self, s):
        s = torch.FloatTensor(s).to(device)
        s_ = s[0:n_actions_continuous]
        mu, sigma, discrete_out = self.actor_model(s)
        dist = torch.distributions.Normal(mu, sigma)
        action = dist.sample()
        discrete_action = self.choose_discrete_action(discrete_out)
        punish = []
        for a__ in action:
            if a__ < 0:
                punish.append(a__,)
            if a__ > 1:
                punish.append(a__ - 1)
        punish = np.array(punish)
        continuous_action = torch.clamp(action, -s_,  self.bound - s_)
        return continuous_action, discrete_action, discrete_out, punish

    def discount_reward(self, rewards, s_):  # N步更新折扣奖励  rewards[batch] s_[num_divide * 2]
        s_ = torch.FloatTensor(s_).to(device)
        target = self.critic_model(s_).detach()  # torch.Size([1])
        target_list = []
        for r in rewards[::-1]:
            target = r + self.gamma * target
            target_list.append(target)
        target_list.reverse()
        target_list = torch.cat(target_list)  # torch.Size([batch])]
        return target_list

    def actor_learn(self, states, actions, advantage):  # [batch, num_d * 2] [batch, num_d * 2] [batch]
        states = torch.FloatTensor(states).to(device)
        actions = torch.FloatTensor(actions).to(device)
        continuous_action = actions[:, 0:n_actions_continuous]
        discrete_action = actions[:, n_actions_continuous:]
        mu, sigma, discrete_out = self.actor_model(states)
        pi = torch.distributions.Normal(mu, sigma)
        old_mu, old_sigma, old_discrete_out = self.actor_old_model(states)
        old_pi = torch.distributions.Normal(old_mu, old_sigma)

        continuous_ratio = torch.exp(pi.log_prob(continuous_action) -
                        old_pi.log_prob(continuous_action))

        continuous_surr = continuous_ratio * advantage.reshape(-1, 1)

        continuous_loss = -torch.mean(torch.min(
                continuous_surr, torch.clamp(continuous_ratio, 1 - self.epsilon,
                1 + self.epsilon) * advantage.reshape(-1, 1)))

        self.continuous_actor_loss.append(continuous_loss)
        self.actor_optim.zero_grad()
        continuous_loss.backward()
        self.actor_optim.step()

        # 离散动作学习
        if self.memory_counter >= DISCRETE_MEMORY_CAPACITY:
            if self.learn_step_counter % TARGET_REPLACE_ITER == 0:
                self.actor_target_model.load_state_dict(self.actor_model.state_dict())
            self.learn_step_counter += 1
            sample_index = np.random.choice(DISCRETE_MEMORY_CAPACITY, 128)
            b_memory = self.memory[sample_index, :]
            b_s = torch.FloatTensor(b_memory[:, :n_states])
            b_a = torch.LongTensor(b_memory[:, n_states + n_actions_continuous:n_states + n_actions])
            b_r = torch.FloatTensor(b_memory[:, n_states + n_actions:n_states + n_actions + 1])
            b_s_ = torch.FloatTensor(b_memory[:, n_states + n_actions + 1:n_states * 2 + n_actions + 1])

            # pso
            b_a_lr = torch.FloatTensor(b_memory[:, n_states * 2 + n_actions + 1:n_states * 2 + n_actions + 2])
            b_c_lr = torch.FloatTensor(b_memory[:, n_states * 2 + n_actions + 2:n_states * 2 + n_actions + 3])
            b_gamma_lr = torch.FloatTensor(b_memory[:, n_states * 2 + n_actions + 3:n_states * 2 + n_actions + 4])

            mu1, sigma1, q_eval = self.actor_model(b_s)
            q_eval_ = []
            for i in range(q_eval.shape[0]):
                q_eval_.append(self.choose_discrete_action_DQN(q_eval[i]).gather(1, b_a[i].unsqueeze(1)))
            q_eval_ = torch.tensor([item.detach().numpy() for item in q_eval_]).squeeze()
            mu2, sigma2, q_next = self.actor_target_model(b_s_)
            q_next_ = []
            for q in q_next:
                q_next_.append(self.choose_discrete_action(q))
            q_next_ = torch.tensor(q_next_).squeeze()
            q_target = b_r + 0.99 * q_next_
            loss_func = nn.MSELoss().to(device)
            loss = loss_func(q_eval_, q_target)
            self.discrete_actor_loss.append(loss)
            loss.requires_grad = True
            self.actor_target_optim.zero_grad()
            loss.backward()
            self.actor_target_optim.step()

            # pso
            b_a_lr = np.array(b_a_lr)
            b_c_lr = np.array(b_c_lr)
            b_r = np.array(b_r)
            b_gamma_lr = np.array(b_gamma_lr)
            x = np.append(b_a_lr, b_c_lr, 1)
            x = np.append(x, b_gamma_lr, 1)
            personal_reward = np.max(b_r)
            personal_best = x[np.argmax(b_r)]
            r1 = np.random.uniform(0, 1)
            r2 = np.random.uniform(0, 1)
            c1 = c2 = 2
            self.v_pso = 0.4 * self.v_pso + c1 * r1 * (personal_best - self.x_pso) + \
                         c2 * r2 * (self.global_best - self.x_pso)
            self.x_pso = self.x_pso + self.v_pso

            if personal_reward > self.global_reward:
                self.global_reward = personal_reward
                self.global_best = personal_best
            self.actor_lr = np.clip(self.x_pso[0], 0.00001, 0.0009).round(6)
            self.critic_lr = np.clip(self.x_pso[1], 0.00001, 0.0001).round(6)
            self.gamma = np.clip(self.x_pso[2], 0, 1).round(4)

    def critic_learn(self, states, targets):
        states = torch.FloatTensor(states).to(device)
        v = self.critic_model(states).reshape(1, -1).squeeze(0)

        loss_func = nn.MSELoss().to(device)
        loss = loss_func(v, targets)

        self.critic_loss.append(loss)

        self.critic_optim.zero_grad()
        loss.backward()
        self.critic_optim.step()

    def cal_adv(self, states, targets):  # 计算优势函数
        states = torch.FloatTensor(states).to(device)
        v = self.critic_model(states)  # torch.Size([batch, num_divide * 2])
        advantage = targets - v.reshape(1, -1).squeeze(0)
        return advantage.detach()  # torch.Size([batch])

    def update(self, states, actions, targets):
        self.actor_old_model.load_state_dict(self.actor_model.state_dict())  # 首先更新旧模型
        advantage = self.cal_adv(states, targets)
        for i in range(self.a_update_steps):  # 更新多次
            self.actor_learn(states, actions, advantage)

        for i in range(self.c_update_steps):  # 更新多次
            self.critic_learn(states, targets)

    def store_transition(self, s, a, r, s_, actor_lr, critic_lr, gamma):                                    # 定义记忆存储函数 (这里输入为一个transition)
        transition = np.hstack((s, a, r, s_, actor_lr, critic_lr, gamma))                                 # 在水平方向上拼接数组
        # 如果记忆库满了，便覆盖旧的数据
        index = self.memory_counter % DISCRETE_MEMORY_CAPACITY                           # 获取transition要置入的行数
        self.memory[index, :] = transition                                      # 置入transition
        self.memory_counter += 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--n_episodes', type=int, default=300)
    parser.add_argument('--len_episode', type=int, default=1024)
    parser.add_argument('--lr', type=float, default=0.0001)
    parser.add_argument('--batch', type=int, default=64)
    parser.add_argument('--gamma', type=float, default=0.9)
    parser.add_argument('--seed', type=int, default=10)
    parser.add_argument('--epsilon', type=float, default=0.1)
    parser.add_argument('--c_update_steps', type=int, default=10)
    parser.add_argument('--a_update_steps', type=int, default=10)
    args = parser.parse_args()

    env = ppo_change_mec_enc.ENV
    # np.random.seed(1)
    num_device = 50
    num_mec = 4
    mec_max_cpu = 12
    mec_q_acc = 12
    t_threshold = 100
    offload_x = np.random.uniform(0, 1, num_device)  # 归一化
    local_f = np.random.uniform(0, 1, num_device)  # 归一化
    # local_f = np.ceil(local_f * (10 ** 9))
    mec_f = np.array([10 ** 10, 10 ** 10, 10 ** 10, 10 ** 10])
    send_p = np.random.uniform(0, 1, num_device)  # 归一化
    channel_c = np.random.uniform(0, 1, num_device)  # 归一化 没用
    d = np.random.randint(0., 500., (num_device, num_mec))
    b = np.random.uniform(100, 1000, num_device)
    b = np.ceil(b * 1000 * 1024)
    mec_c = np.random.uniform(0, 1, num_device)   # 归一化
    task_priority = np.random.uniform(0, 1, num_device)
    task_quality = np.random.uniform(0, 1, num_device)  # 归一化

    torch.manual_seed(args.seed)

    n_states = num_device * 4
    n_actions_discrete = num_device * 8
    n_actions_continuous = num_device * 2
    n_actions = num_device * 3
    bound = 1

    agent = PPO(n_states, n_actions_discrete, n_actions_continuous, bound, args).to(device)

    all_ep_r = []
    all_cost_all = []
    all_delay_all = []
    all_energy_all = []
    all_s_all = []

    for episode in range(args.n_episodes):

        mec = env(num_device, offload_x, local_f, mec_f, send_p, channel_c, d, b, num_mec,
                    task_quality, mec_c, t_threshold, mec_max_cpu, mec_q_acc, task_priority)
        ep_r = 0
        s = np.append(mec.offload_x, mec.send_p)
        s = np.append(s, mec.local_f)
        s = np.append(s, mec.mec_c)
        mec.calculate_normalized_parameter(offload_x, local_f, send_p, mec_c)
        states, actions, rewards = [], [], []
        for t in range(args.len_episode):

            continuous_a, discrete_a, discrete_action, punish = agent.choose_action(s)
            continuous_a = np.array(continuous_a)
            s_pro = s[0:n_actions_continuous]
            continuous_a = np.clip(continuous_a, -s_pro, 1 - s_pro)
            a = np.append(continuous_a, discrete_a)
            s, a, r, s_, e_all_, t_all_, cost_all_ = mec.step(s, a, n_actions_continuous)

            agent.store_transition(s, a, r, s_, agent.actor_lr, agent.critic_lr, agent.gamma)
            discrete_action = np.array(discrete_action.detach())
            a = np.append(continuous_a, discrete_action)
            ep_r += r
            states.append(s)
            actions.append(a)
            rewards.append(r)

            s = s_

            if (t + 1) % args.batch == 0 or t == args.len_episode - 1:  # N步更新
                states = np.array(states)
                actions = np.array(actions)
                rewards = np.array(rewards)
                # 折扣奖励 r + self.gamma * target  # target = critic_model(s_).detach()
                targets = agent.discount_reward(rewards, s_)  # [detach]
                agent.update(states, actions, targets)  # 进行actor和critic网络的更新
                states, actions, rewards = [], [], []

        print('Episode: ', episode, ' Reward: %.4f' % ep_r, 'delay:%.4f' % t_all_, 'consumption: %4f' % e_all_,
              'cost_all:%4f' % cost_all_)
        # print(agent.actor_lr, agent.critic_lr, agent.gamma)

        # if episode == 0:
        #     all_ep_r.append(ep_r)
        # else:
        #     all_ep_r.append(all_ep_r[-1] * 0.9 + ep_r * 0.1)  # 平滑
        all_ep_r.append(ep_r)
        all_cost_all.append(cost_all_)
        all_delay_all.append(t_all_)
        all_energy_all.append(e_all_)
        all_s_all.append(s_)

    plt.plot(np.arange(len(all_ep_r)), all_ep_r)
    plt.show()
    plt.plot(np.arange(len(all_cost_all)), all_cost_all)
    plt.show()
    plt.plot(np.arange(len(agent.continuous_actor_loss)), agent.continuous_actor_loss)
    plt.show()
    plt.plot(np.arange(len(agent.discrete_actor_loss)), agent.discrete_actor_loss)
    plt.show()
    plt.plot(np.arange(len(agent.critic_loss)), agent.critic_loss)
    plt.show()
    print(np.min(all_delay_all))
    print(np.min(all_energy_all))
    print(np.min(all_cost_all))
    print(all_s_all[np.argmin(all_cost_all)][0:50])
    print(all_s_all[np.argmin(all_cost_all)][50:100])
    print(all_s_all[np.argmin(all_cost_all)][100:150])
    print(all_s_all[np.argmin(all_cost_all)][150:200])