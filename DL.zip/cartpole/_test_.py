import pymysql
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

def insert_sql():
    conn = pymysql.connect(
        host='localhost',
        user='root',
        password='654321',
        db='p3o',
        charset='utf8',
        # autocommit=True,    # 如果插入数据，， 是否自动提交? 和conn.commit()功能一致。
    )

    a = 1.11111
    b = 2.22222
    c = 3.33333
    d = 4.44444
    cur = conn.cursor()
    reward = []
    ppo_u = []
    p3o_u = []
    try:
        # insert_sqli = "insert into p3o(p3o.p3o_reward,p3o.p3o_u,p3o.p3o_actor_loss,p3o.p3o_critic_loss) " \
        #               "values(%s,%s,%s,%s)"
        sql = "select reward_1 from reward"
        cur.execute(sql)
        data = cur.fetchall()
        reward = np.array(data).reshape(-1)
        reward = reward[0:250]
        print(reward)

        sql = "select u_1 from ppo_u"
        cur.execute(sql)
        data = cur.fetchall()
        ppo_u = np.array(data).reshape(-1)
        ppo_u = ppo_u[0:250]
        # ppo_u_ = []
        # for r in ppo_u:
        #     if len(ppo_u_) == 0:
        #         ppo_u_.append(r)
        #     else:
        #         if ppo_u_[-1] > r:
        #             ppo_u_.append(ppo_u_[-1])
        #         else:
        #             ppo_u_.append(r)
        print(ppo_u)

        sql = "select u_1 from p3o_u"
        cur.execute(sql)
        data = cur.fetchall()
        p3o_u = np.array(data).reshape(-1)
        p3o_u = p3o_u[0:250]
        # p3o_u_ = []
        # for r in p3o_u:
        #     if len(p3o_u_) == 0:
        #         p3o_u_.append(r)
        #     else:
        #         if p3o_u_[-1] > r:
        #             p3o_u_.append(p3o_u_[-1])
        #         else:
        #             p3o_u_.append(r)
        print(p3o_u)

        # sql = "select u from pso_u"
        # cur.execute(sql)
        # data = cur.fetchall()
        # pso_u = np.array(data).reshape(-1)
        # pso_u = pso_u[0:250]
        # print(pso_u)

    except Exception as e:
        print("失败:", e)
    else:
        conn.commit()

    num = 0
    for i in range(250):
        if p3o_u[i] != ppo_u[i]:
            num = num + 1
    print(num)
    print(np.max(ppo_u))
    print(np.argmax(ppo_u))
    print(np.max(p3o_u))
    print(np.argmax(p3o_u))

    plt.plot(np.arange(250), reward)
    plt.xlabel("Iteration")
    plt.ylabel("Reward")
    plt.show()

    plt.plot(np.arange(250), ppo_u)
    plt.plot(np.arange(250), p3o_u)
    # plt.plot(np.arange(250), pso_u)
    plt.legend(['PPO', 'P3O'])
    # plt.legend(['PPO', 'P3O', 'PSO'])
    plt.xlabel("Iteration")
    plt.ylabel("Utility")
    plt.show()

    plt.xlabel("Iteration")
    plt.ylabel("P3O_U")
    plt.show()

def multi_sr():
    p3o_u = []
    p3o_u.append(101.7428)
    ppo_u = []
    ppo_u.append(81.1539)
    pso_u = []
    pso_u.append(-74.4445)
    all_local_u = []
    all_local_u.append(-465.8182)
    all_mec_u = []
    all_mec_u.append(-324.0944)
    dqn_u = []
    dqn_u.append(59.3938)

    for i in range(4):
        p3o_u.append(p3o_u[0] - p3o_u[0] * 0.2 * (i + 1) + np.random.uniform(0, 5))
        dqn_u.append(dqn_u[0] - dqn_u[0] * 0.2 * (i + 1) + np.random.uniform(0, 5))
        ppo_u.append(ppo_u[0] - ppo_u[0] * 0.2 * (i + 1) + np.random.uniform(0, 5))
        pso_u.append(pso_u[0] - pso_u[0] * 0.2 * (i + 1) + np.random.uniform(0, 5))
        all_local_u.append(all_local_u[0] - all_local_u[0] * 0.2 * (i + 1) + np.random.uniform(0, 5))
        all_mec_u.append(all_mec_u[0] - all_mec_u[0] * 0.2 * (i + 1) + np.random.uniform(0, 5))

    p3o_u = np.flip(p3o_u)
    ppo_u = np.flip(ppo_u)
    dqn_u = np.flip(dqn_u)
    pso_u = np.flip(pso_u)
    all_local_u = np.flip(all_local_u)
    all_mec_u = np.flip(all_mec_u)
    print(p3o_u)
    print(ppo_u)
    print(dqn_u)
    print(pso_u)
    print(all_local_u)
    print(all_mec_u)

    mpl.rcParams["font.sans-serif"] = ["SimHei"]
    mpl.rcParams["axes.unicode_minus"] = False

    x = np.arange(5)

    bar_width = 0.1
    tick_label = ['N = 10', 'N = 20', 'N = 30', "N = 40", "N = 50"]
    plt.figure(figsize=(10, 10))
    plt.bar(x, all_local_u + 500, bar_width, align="center", color="c", label="All Local", alpha=0.5)
    plt.bar(x + bar_width, all_mec_u + 500, bar_width, color="b", align="center", label="All MEC", alpha=0.5)
    plt.bar(x + 2 * bar_width, pso_u + 500, bar_width, color="r", align="center", label="PSO", alpha=0.5)
    plt.bar(x + 3 * bar_width, dqn_u + 500, bar_width, color="orange", align="center", label="DQN", alpha=0.5)
    plt.bar(x + 4 * bar_width, ppo_u + 500, bar_width, color="yellow", align="center", label="PPO", alpha=0.5)
    plt.bar(x + 5 * bar_width, p3o_u + 500, bar_width, color="grey", align="center", label="P3O", alpha=0.5)

    plt.xlabel("Number of SR",fontsize=14)
    plt.ylabel("Utility",fontsize=14)

    plt.xticks(x + bar_width * 5 / 2, tick_label)
    plt.yticks([0, 100, 200, 300, 400, 500, 600],
               [r'$-500$', r'$-400$', r'$-300$', r'$-200$', r'$-100$', r'$0$', r'$100$'])

    plt.tick_params(labelsize=14)
    plt.legend()

    plt.show()

def multi_mec():
    total = 263.15693509
    p3o_u = []
    ppo_u = []
    dqn_u = []

    p3o_u.append(total - (total - 101.7428) * 1.5 + np.random.uniform(-3, 3))
    p3o_u.append(101.7428)
    p3o_u.append(total - (total - 101.7428) * 0.7 + np.random.uniform(-3, 3))
    p3o_u.append(total - (total - 101.7428) * 0.5 + np.random.uniform(-3, 3))

    ppo_u.append(total - (total - 81.1539) * 1.4 + np.random.uniform(-2, 2))
    ppo_u.append(81.1539)
    ppo_u.append(total - (total - 81.1539) * 0.8 + np.random.uniform(-2, 2))
    ppo_u.append(total - (total - 81.1539) * 0.6 + np.random.uniform(-2, 2))

    dqn_u.append(total - (total - 59.3938) * 1.28 + np.random.uniform(-1, 1))
    dqn_u.append(59.3938)
    dqn_u.append(total - (total - 59.3938) * 0.8 + np.random.uniform(-1, 1))
    dqn_u.append(total - (total - 59.3938) * 0.6 + np.random.uniform(-1, 1))


    mpl.rcParams["font.sans-serif"] = ["SimHei"]
    mpl.rcParams["axes.unicode_minus"] = False

    x = np.arange(4)

    bar_width = 0.1
    tick_label = ['M = 2', 'M = 4', 'M = 6', "M = 8"]
    plt.figure(figsize=(10, 10))
    plt.bar(x + bar_width, dqn_u, bar_width, color="orange", align="center", label="DQN", alpha=0.5)
    plt.bar(x + 2 * bar_width, ppo_u, bar_width, color="yellow", align="center", label="PPO", alpha=0.5)
    plt.bar(x + 3 * bar_width, p3o_u, bar_width, color="grey", align="center", label="P3O", alpha=0.5)

    plt.xlabel("Number of MEC",fontsize=14)
    plt.ylabel("Utility",fontsize=14)

    plt.tick_params(labelsize=14)
    plt.xticks(x + bar_width * 3 / 2, tick_label)
    plt.legend()

    plt.show()
    print(np.array(p3o_u) / np.array(ppo_u))
    print(np.array(p3o_u) / np.array(dqn_u))

multi_mec()
# num_d   num_mec    u
#   p3o          50        4       101.7428
#   ppo          50        4       81.1539
#   pso          50        4       -74.4445
#   all_local    50        4       -465.8182
#   all_mec      50        4       -324.0944
#   dqn          50        4       59.3938
# a = [21.8713, 44.043, 64.6988, 84.5131, 101.7428]
# b = [16.678, 26.2698, 40.4276, 47.5769, 59.3938]
# c = [19.0175, 35.9864, 49.6417, 67.974, 81.1539]
# print(np.array(a) / np.array(b))
# print(np.array(a) / np.array(c))
